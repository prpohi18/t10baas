# t10baas
Koostage Java rakendus, mille abil on võimalik andmebaasi andmeid vaadata ning neid sinna lisada,
paremal juhul ka kustutada ja muuta.
